REU Wave Player v0 (PoC)
------------------------

- works with any REU type (real and emulated) and size (up to 16Mb) [1]
- cycle exact 8bit replay in 22050Hz and 44100Hz
- source included (KickAss format)
- free bugs included too (playing does not stop at end of file, and wrapping
  around does not work correctly either.)
- room for improvement for you to fill (sound quality can perhaps be further
  improved by reordering and/or changing the timing of sid writes, or even by
  using the filter.)
- test files that prove my horrible taste of music and inability to properly
  downsample to 8 bit.
- all rights reversed, no restrictions. feel free to make more out of it. i wont

[1] this is a bold claim, it was infact only tested in VICE. i cant be bothered,
    just try it yourself :)

to play your own files, convert them to plain 8bit unsigned wav files in either
22050Hz or 44100Hz and pad them accordingly if needed.

VICE:
x64 -reu -reusize 16384 -reuimage test22k.reu player22050.prg
x64 -reu -reusize 16384 -reuimage test44k.reu player44100.prg

actual REU:
- load REU image into REU (i have no idea how you will do this :=P)
- load and run the respective player program

1541u:
- load REU image by choosing "Load into REU"
- load and run the respective player program

Chameleon:
- load REU image by pressing enter on image
- load and run the respective player program

gpz 02/2012
